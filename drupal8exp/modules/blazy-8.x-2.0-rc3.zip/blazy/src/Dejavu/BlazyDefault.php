<?php

namespace Drupal\blazy\Dejavu;

use Drupal\blazy\BlazyDefault as BlazyNewDefault;

/**
 * Defines shared plugin default settings for field formatter and Views style.
 *
 * @deprecated for \Drupal\blazy\BlazyDefault, and will be removed at 8.x-2+.
 */
class BlazyDefault extends BlazyNewDefault {}
